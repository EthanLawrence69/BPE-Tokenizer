import HeroCard from "../components/HeroCard";

const HomePage = () => {
  return (
    <div>
      {/* Home Page Text */}
      <HeroCard />
    </div>
  );
};

export default HomePage;
